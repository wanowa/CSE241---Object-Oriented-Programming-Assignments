
/**
 * 
 * @author YeTeA
 *
 * @param <E>List interface has generic type <E>. It extends Collection interface.
 */
public interface List<E> extends Collection<E>{

}