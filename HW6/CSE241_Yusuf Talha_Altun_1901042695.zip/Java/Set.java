
/**
 * 
 * @author YeTeA
 *
 * @param <E> Set interface has generic type <E>. It extends Collection interface.
 */
public interface Set<E> extends Collection<E>{

}